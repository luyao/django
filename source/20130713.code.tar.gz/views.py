#coding=utf8
#!/bin/python
# Program:
# 		
# History:
# Author: luyao(yaolu1103@gmail.com)
# Date:  2013/06/28 15:05:47

from django.http import HttpResponse, Http404
import datetime
from django.template import Context, RequestContext

from django.template.loader import get_template
from django.shortcuts import render_to_response


def hello(request):
	return HttpResponse("Hello world")

def hour_ahead(request, time):
	try:
		ahead = int(time)
	except ValueError:
		raise Http404()
	sDay = datetime.datetime.now() + datetime.timedelta(hours=ahead)
	t = get_template( 'time/time.html' )
	html = t.render( Context({'ahead':ahead, 'future_time':sDay}) )
	return HttpResponse(html)

def hour_ahead_ex(request, time):
	try:
		ahead = int(time)
	except ValueError:
		raise Http404()
	future_time = datetime.datetime.now() + datetime.timedelta(hours=ahead)
	return render_to_response('time/time.html', locals() )

def new_homepage(request):
	t = get_template('home/new_homepage.html')
	c = RequestContext(request, locals())
	return HttpResponse(t.render(c))

def scroll_demo(request):
	t = get_template('scrollable/scroll_demo.html')
	c = RequestContext(request, locals())
	return HttpResponse(t.render(c))

