#coding=utf8
#!/bin/python
# Program:
# 		
# History:
# Author: luyao(yaolu1103@gmail.com)
# Date:  2013/06/30 19:36:59


from django.db import models

# Create your models here.
#this models can be used for admin functions
#class SitePages(models.Model):
#	title          = models.CharField(max_length=100)
#	description    = models.TextField()
#	image_url      = models.CharField(max_length=200)  #the nav items, may have the bg img

