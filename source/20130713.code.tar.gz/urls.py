from django.conf.urls.defaults import *
#activate the static
from django.conf import settings

from mysite.views import *

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
    # Example:
    # (r'^mysite/', include('mysite.foo.urls')),

    # Uncomment the admin/doc line below and add 'django.contrib.admindocs' 
    # to INSTALLED_APPS to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # (r'^admin/', include(admin.site.urls)),
	url(r'^static/(?P<path>.*)$','django.views.static.serve',{'document_root':settings.STATIC_ROOT}),
)

urlpatterns += patterns('',
    (r'^hello/$', hello),
    (r'^time/(\d{1,2})/$', hour_ahead_ex),
	#home page
	(r'^home/$', new_homepage),
)

urlpatterns += patterns('',
    (r'^scroll/$', scroll_demo),
)

urlpatterns += patterns('sspayment.views',
	#cart's view
	(r'^cart/view/$', 'cart_view'),
	#add the product
	(r'^cart/add/(?P<id>[^/]+)/$', 'add_to_cart'),  
	#delete one product
	(r'^cart/del/(?P<id>[^/]+)/$', 'del_from_cart'),  
	#clean the cart
	(r'^cart/clean/', 'clean_cart'),
	#pay me!
	(r'^pay/', 'pay'),
)

